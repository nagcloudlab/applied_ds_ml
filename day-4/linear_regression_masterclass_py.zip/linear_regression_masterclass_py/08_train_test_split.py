"""
08_train_test_split.py

Goal:
- Train on old examples and test on unseen examples.
- This checks whether the model generalizes.
"""

import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split


def main():
    data = {
        "study_hours": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        "score": [36, 39, 47, 51, 58, 63, 68, 72, 81, 85],
    }

    df = pd.DataFrame(data)
    X = df[["study_hours"]]
    y = df["score"]

    X_train, X_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=0.3,
        random_state=42,
    )

    model = LinearRegression()
    model.fit(X_train, y_train)

    train_pred = model.predict(X_train)
    test_pred = model.predict(X_test)

    train_mae = mean_absolute_error(y_train, train_pred)
    test_mae = mean_absolute_error(y_test, test_pred)
    test_mse = mean_squared_error(y_test, test_pred)
    test_rmse = np.sqrt(test_mse)
    test_r2 = r2_score(y_test, test_pred)

    print("Training data:")
    print(pd.concat([X_train, y_train], axis=1).sort_index())

    print("\nTesting data:")
    print(pd.concat([X_test, y_test], axis=1).sort_index())

    print("\nLearned model:")
    print("Slope m:", model.coef_[0])
    print("Intercept c:", model.intercept_)

    results = X_test.copy()
    results["actual_score"] = y_test
    results["predicted_score"] = test_pred
    results["residual"] = results["actual_score"] - results["predicted_score"]

    print("\nTest predictions:")
    print(results.sort_index())

    print("\nMetrics:")
    print("Training MAE:", train_mae)
    print("Testing MAE :", test_mae)
    print("Testing RMSE:", test_rmse)
    print("Testing R²  :", test_r2)

    print("\nNote:")
    print("This dataset is tiny, so metrics can change a lot with different splits.")


if __name__ == "__main__":
    main()
