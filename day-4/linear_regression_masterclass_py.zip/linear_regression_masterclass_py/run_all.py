"""
run_all.py

Runs all lesson scripts in order in the same Python process.
This is faster than launching a new Python process for every file.
"""

import runpy
from pathlib import Path


LESSON_FILES = [
    "00_dataset_and_terms.py",
    "01_slope_from_two_points.py",
    "02_intercept_and_prediction_rule.py",
    "03_candidate_lines_and_errors.py",
    "04_best_fit_with_numpy.py",
    "05_pandas_step_by_step.py",
    "06_sklearn_linear_regression.py",
    "07_evaluation_metrics.py",
    "08_train_test_split.py",
    "09_underfitting_overfitting_demo.py",
    "10_outlier_and_extrapolation.py",
    "11_multiple_linear_regression_preview.py",
]


def main():
    base_dir = Path(__file__).parent

    for lesson in LESSON_FILES:
        print("\n" + "#" * 80)
        print("Running", lesson)
        print("#" * 80)
        runpy.run_path(str(base_dir / lesson), run_name="__main__")


if __name__ == "__main__":
    main()
