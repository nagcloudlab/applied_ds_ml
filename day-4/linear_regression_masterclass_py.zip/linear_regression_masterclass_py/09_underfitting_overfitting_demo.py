"""
09_underfitting_overfitting_demo.py

Goal:
- Compare underfitting, good fit, and overfitting.
- Underfitting: model is too simple.
- Good fit: model captures the useful pattern.
- Overfitting: model memorizes noise and performs worse on new data.
"""

import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import PolynomialFeatures


def main():
    # Small noisy dataset: score generally increases with study hours.
    df = pd.DataFrame({
        "study_hours": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
        "score": [36, 39, 47, 51, 58, 63, 68, 72, 81, 85, 86, 88],
    })

    X = df[["study_hours"]]
    y = df["score"]

    X_train, X_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=0.33,
        random_state=7,
    )

    # 1. Underfitting model: always predict the training average.
    train_average = y_train.mean()
    underfit_train_pred = np.full(shape=len(y_train), fill_value=train_average)
    underfit_test_pred = np.full(shape=len(y_test), fill_value=train_average)

    # 2. Good fit model: simple Linear Regression.
    good_model = LinearRegression()
    good_model.fit(X_train, y_train)
    good_train_pred = good_model.predict(X_train)
    good_test_pred = good_model.predict(X_test)

    # 3. Overfitting-style model: very high-degree polynomial on very small data.
    # This is mainly for teaching. In real projects, use validation carefully.
    overfit_model = make_pipeline(PolynomialFeatures(degree=8), LinearRegression())
    overfit_model.fit(X_train, y_train)
    overfit_train_pred = overfit_model.predict(X_train)
    overfit_test_pred = overfit_model.predict(X_test)

    summary = pd.DataFrame({
        "model": ["Underfit constant model", "Good linear model", "Overfit high-degree model"],
        "train_MAE": [
            mean_absolute_error(y_train, underfit_train_pred),
            mean_absolute_error(y_train, good_train_pred),
            mean_absolute_error(y_train, overfit_train_pred),
        ],
        "test_MAE": [
            mean_absolute_error(y_test, underfit_test_pred),
            mean_absolute_error(y_test, good_test_pred),
            mean_absolute_error(y_test, overfit_test_pred),
        ],
    })

    print("Underfitting vs good fit vs overfitting")
    print(summary)

    print("\nInterpretation guide:")
    print("High train error + high test error     -> underfitting")
    print("Low train error + low test error       -> good fit")
    print("Very low train error + high test error -> overfitting")


if __name__ == "__main__":
    main()
