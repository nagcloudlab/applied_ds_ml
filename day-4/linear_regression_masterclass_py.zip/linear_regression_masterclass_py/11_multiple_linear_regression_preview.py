"""
11_multiple_linear_regression_preview.py

Goal:
- Preview the next model: Multiple Linear Regression.
- Instead of one feature, we use multiple features.

Simple Linear Regression:
    score = c + m * study_hours

Multiple Linear Regression:
    score = b0 + b1 * study_hours + b2 * attendance + b3 * previous_score
"""

import pandas as pd
from sklearn.linear_model import LinearRegression


def main():
    data = {
        "study_hours": [1, 2, 3, 4, 5, 6, 7, 8],
        "attendance_percent": [60, 65, 70, 75, 80, 85, 90, 95],
        "previous_score": [40, 45, 50, 55, 60, 65, 70, 75],
        "exam_score": [38, 43, 50, 56, 63, 68, 75, 82],
    }

    df = pd.DataFrame(data)

    X = df[["study_hours", "attendance_percent", "previous_score"]]
    y = df["exam_score"]

    model = LinearRegression()
    model.fit(X, y)

    print("Dataset:")
    print(df)

    print("\nIntercept b0:", model.intercept_)

    coefficients = pd.DataFrame({
        "feature": X.columns,
        "coefficient": model.coef_,
    })

    print("\nCoefficients:")
    print(coefficients)

    new_student = pd.DataFrame({
        "study_hours": [6],
        "attendance_percent": [88],
        "previous_score": [67],
    })

    prediction = model.predict(new_student)[0]

    print("\nNew student:")
    print(new_student)
    print("Predicted exam score:", prediction)

    print("\nNote:")
    print("This preview dataset is tiny and only for concept explanation.")


if __name__ == "__main__":
    main()
