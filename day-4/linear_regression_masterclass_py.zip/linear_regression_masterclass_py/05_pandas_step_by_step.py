"""
05_pandas_step_by_step.py

Goal:
- Make the Linear Regression math visible row by row using a table.
- Calculate slope, intercept, predictions, residuals, and squared errors.
"""

import pandas as pd


def main():
    data = {
        "study_hours": [1, 2, 3, 4, 5],
        "score": [36, 39, 47, 51, 58],
    }

    df = pd.DataFrame(data)

    x_mean = df["study_hours"].mean()
    y_mean = df["score"].mean()

    df["x_deviation"] = df["study_hours"] - x_mean
    df["y_deviation"] = df["score"] - y_mean

    df["xy_deviation_product"] = df["x_deviation"] * df["y_deviation"]
    df["x_deviation_square"] = df["x_deviation"] ** 2

    numerator = df["xy_deviation_product"].sum()
    denominator = df["x_deviation_square"].sum()

    m = numerator / denominator
    c = y_mean - m * x_mean

    df["predicted_score"] = m * df["study_hours"] + c
    df["residual"] = df["score"] - df["predicted_score"]
    df["absolute_error"] = df["residual"].abs()
    df["squared_error"] = df["residual"] ** 2

    mae = df["absolute_error"].mean()
    mse = df["squared_error"].mean()

    print("Original data with calculations:")
    print(df)

    print("\nSummary values:")
    print("x_mean:", x_mean)
    print("y_mean:", y_mean)
    print("numerator:", numerator)
    print("denominator:", denominator)
    print("slope m:", m)
    print("intercept c:", c)
    print("MAE:", mae)
    print("MSE:", mse)

    print("\nFinal model:")
    print(f"Predicted Score = {m:.2f} × Study Hours + {c:.2f}")


if __name__ == "__main__":
    main()
