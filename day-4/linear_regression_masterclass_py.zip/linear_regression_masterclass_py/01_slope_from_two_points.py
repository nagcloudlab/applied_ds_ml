"""
01_slope_from_two_points.py

Goal:
- Understand slope m.
- Slope shows how much y changes when x increases by 1 unit.
"""


def main():
    # Two points from a simple perfect dataset:
    # Point 1: 1 study hour -> 35 marks
    # Point 2: 5 study hours -> 55 marks
    x1, y1 = 1, 35
    x2, y2 = 5, 55

    print("Point 1:", (x1, y1))
    print("Point 2:", (x2, y2))

    # Formula:
    # m = (y2 - y1) / (x2 - x1)
    m = (y2 - y1) / (x2 - x1)

    print("\nSlope formula:")
    print("m = (y2 - y1) / (x2 - x1)")
    print(f"m = ({y2} - {y1}) / ({x2} - {x1})")
    print(f"m = {(y2 - y1)} / {(x2 - x1)}")
    print("m =", m)

    print("\nInterpretation:")
    print("For every extra 1 study hour, score increases by", m, "marks.")


if __name__ == "__main__":
    main()
