"""
00_dataset_and_terms.py

Goal:
- Understand dataset, feature, target, and regression problem.
- This is the starting point for the Linear Regression masterclass.
"""

import pandas as pd


def main():
    data = {
        "student": ["A", "B", "C", "D", "E"],
        "study_hours": [1, 2, 3, 4, 5],
        "exam_score": [36, 39, 47, 51, 58],
    }

    df = pd.DataFrame(data)

    print("Dataset: Past student examples")
    print(df)

    print("\nML terms:")
    print("Feature / Input  : study_hours")
    print("Target / Output  : exam_score")
    print("Problem type     : Regression, because we predict a number")

    X = df[["study_hours"]]
    y = df["exam_score"]

    print("\nFeature table X:")
    print(X)

    print("\nTarget column y:")
    print(y)


if __name__ == "__main__":
    main()
