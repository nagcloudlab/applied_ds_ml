"""
07_evaluation_metrics.py

Goal:
- Evaluate a regression model using MAE, MSE, RMSE, and R².
"""

import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score


def main():
    data = {
        "study_hours": [1, 2, 3, 4, 5],
        "score": [36, 39, 47, 51, 58],
    }

    df = pd.DataFrame(data)
    X = df[["study_hours"]]
    y = df["score"]

    model = LinearRegression()
    model.fit(X, y)

    y_pred = model.predict(X)

    df["predicted_score"] = y_pred
    df["residual"] = df["score"] - df["predicted_score"]
    df["absolute_error"] = df["residual"].abs()
    df["squared_error"] = df["residual"] ** 2

    mae = mean_absolute_error(y, y_pred)
    mse = mean_squared_error(y, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y, y_pred)

    print("Actual vs predicted with errors:")
    print(df)

    print("\nEvaluation metrics:")
    print("MAE  =", mae, "  -> average absolute mistake")
    print("MSE  =", mse, "  -> average squared mistake")
    print("RMSE =", rmse, "  -> error in original unit")
    print("R²   =", r2, "  -> explained variation")


if __name__ == "__main__":
    main()
