"""
06_sklearn_linear_regression.py

Goal:
- Train Linear Regression using sklearn.
- Compare learned slope and intercept with the manual calculation.
"""

import pandas as pd
from sklearn.linear_model import LinearRegression


def main():
    data = {
        "study_hours": [1, 2, 3, 4, 5],
        "score": [36, 39, 47, 51, 58],
    }

    df = pd.DataFrame(data)

    # X is a 2D feature table.
    X = df[["study_hours"]]

    # y is a 1D target column.
    y = df["score"]

    model = LinearRegression()
    model.fit(X, y)

    m = model.coef_[0]
    c = model.intercept_

    print("Learned slope m:", m)
    print("Learned intercept c:", c)
    print(f"Model: Predicted Score = {m:.2f} × Study Hours + {c:.2f}")

    df["predicted_score"] = model.predict(X)
    df["residual"] = df["score"] - df["predicted_score"]

    print("\nActual vs predicted:")
    print(df)

    new_hours = 6
    new_prediction = model.predict(pd.DataFrame({"study_hours": [new_hours]}))[0]
    print(f"\nPrediction for {new_hours} study hours:", new_prediction)


if __name__ == "__main__":
    main()
