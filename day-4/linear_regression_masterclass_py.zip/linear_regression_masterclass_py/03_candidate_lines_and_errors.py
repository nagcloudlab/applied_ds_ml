"""
03_candidate_lines_and_errors.py

Goal:
- See how Linear Regression compares possible lines.
- Learn Actual, Predicted, Error, Absolute Error, Squared Error, and MSE.
"""

import pandas as pd


def evaluate_line(x_values, y_values, m, c):
    rows = []

    for x, actual in zip(x_values, y_values):
        predicted = m * x + c
        error = actual - predicted
        abs_error = abs(error)
        squared_error = error ** 2

        rows.append({
            "x": x,
            "actual_y": actual,
            "predicted_y": predicted,
            "error": error,
            "absolute_error": abs_error,
            "squared_error": squared_error,
        })

    df = pd.DataFrame(rows)
    mse = df["squared_error"].mean()
    mae = df["absolute_error"].mean()

    return df, mae, mse


def main():
    x_values = [1, 2, 3]
    y_values = [35, 40, 45]

    candidate_lines = [
        {"name": "Line A", "m": 4, "c": 30},
        {"name": "Line B", "m": 5, "c": 30},
        {"name": "Line C", "m": 6, "c": 30},
    ]

    summary = []

    for line in candidate_lines:
        name = line["name"]
        m = line["m"]
        c = line["c"]

        print("\n" + "=" * 70)
        print(f"{name}: predicted_y = {m}x + {c}")
        print("=" * 70)

        result_df, mae, mse = evaluate_line(x_values, y_values, m, c)
        print(result_df)

        print("\nMAE:", mae)
        print("MSE:", mse)

        summary.append({
            "line": name,
            "formula": f"y_hat = {m}x + {c}",
            "MAE": mae,
            "MSE": mse,
        })

    print("\n" + "=" * 70)
    print("Summary: lower MSE is better")
    print("=" * 70)
    summary_df = pd.DataFrame(summary)
    print(summary_df)

    best = min(summary, key=lambda row: row["MSE"])
    print("\nBest line:", best["formula"])


if __name__ == "__main__":
    main()
