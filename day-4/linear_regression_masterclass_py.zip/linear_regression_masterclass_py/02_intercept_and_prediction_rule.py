"""
02_intercept_and_prediction_rule.py

Goal:
- Understand intercept c.
- Build a prediction formula y_hat = mx + c.
"""


def main():
    # We already know slope from the previous example.
    m = 5

    # Use one known point: x = 1, y = 35
    x = 1
    y = 35

    # Formula:
    # c = y - mx
    c = y - m * x

    print("Known point: x =", x, ", y =", y)
    print("Known slope m =", m)

    print("\nIntercept formula:")
    print("c = y - mx")
    print(f"c = {y} - {m} × {x}")
    print("c =", c)

    print("\nFinal model:")
    print(f"Predicted Score = {m} × Study Hours + {c}")

    print("\nPrediction table:")
    print("Study Hours | Predicted Score")
    print("------------|----------------")
    for study_hours in range(0, 7):
        predicted_score = m * study_hours + c
        print(f"{study_hours:11} | {predicted_score:15}")

    new_hours = 6
    predicted = m * new_hours + c
    print(f"\nPrediction for {new_hours} study hours = {predicted} marks")


if __name__ == "__main__":
    main()
