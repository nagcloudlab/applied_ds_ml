"""
04_best_fit_with_numpy.py

Goal:
- Calculate the best-fit slope m and intercept c manually using NumPy.
- Use the realistic dataset from the slides.

Formula:
    m = sum((x - x_mean) * (y - y_mean)) / sum((x - x_mean)^2)
    c = y_mean - m * x_mean
"""

import numpy as np


def main():
    x = np.array([1, 2, 3, 4, 5], dtype=float)
    y = np.array([36, 39, 47, 51, 58], dtype=float)

    x_mean = np.mean(x)
    y_mean = np.mean(y)

    x_deviation = x - x_mean
    y_deviation = y - y_mean

    numerator = np.sum(x_deviation * y_deviation)
    denominator = np.sum(x_deviation ** 2)

    m = numerator / denominator
    c = y_mean - m * x_mean

    y_pred = m * x + c
    residuals = y - y_pred
    squared_errors = residuals ** 2
    mse = np.mean(squared_errors)

    print("x values:", x)
    print("y values:", y)

    print("\nMeans:")
    print("x_mean =", x_mean)
    print("y_mean =", y_mean)

    print("\nDeviations:")
    print("x - x_mean =", x_deviation)
    print("y - y_mean =", y_deviation)

    print("\nSlope calculation:")
    print("numerator   = sum((x - x_mean) * (y - y_mean)) =", numerator)
    print("denominator = sum((x - x_mean)^2)               =", denominator)
    print("m = numerator / denominator =", m)

    print("\nIntercept calculation:")
    print("c = y_mean - m * x_mean")
    print(f"c = {y_mean} - {m} * {x_mean}")
    print("c =", c)

    print("\nFinal model:")
    print(f"Predicted Score = {m:.2f} × Study Hours + {c:.2f}")

    print("\nPredictions:")
    for xi, actual, pred, residual in zip(x, y, y_pred, residuals):
        print(f"x={xi:.0f}, actual={actual:.1f}, predicted={pred:.1f}, residual={residual:.1f}")

    print("\nMSE =", mse)


if __name__ == "__main__":
    main()
