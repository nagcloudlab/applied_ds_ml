Linear Regression Masterclass - Python Files

These scripts match the 60-slide Linear Regression deck.
They are designed for incremental teaching.

Suggested teaching order:

00_dataset_and_terms.py
- Dataset, feature, target, regression idea

01_slope_from_two_points.py
- Slope m from two points

02_intercept_and_prediction_rule.py
- Intercept c and prediction formula

03_candidate_lines_and_errors.py
- Compare possible lines and errors

04_best_fit_with_numpy.py
- Manual best-fit calculation using NumPy

05_pandas_step_by_step.py
- Same math shown row-by-row in a table

06_sklearn_linear_regression.py
- Training Linear Regression with sklearn

07_evaluation_metrics.py
- MAE, MSE, RMSE, R²

08_train_test_split.py
- Train on old data, test on unseen data

09_underfitting_overfitting_demo.py
- Underfitting, good fit, and overfitting comparison

10_outlier_and_extrapolation.py
- Outlier impact and extrapolation risk

11_multiple_linear_regression_preview.py
- Preview of the next model

How to run one file:
python 00_dataset_and_terms.py

How to run all files:
python run_all.py

Install dependencies:
pip install -r requirements.txt
