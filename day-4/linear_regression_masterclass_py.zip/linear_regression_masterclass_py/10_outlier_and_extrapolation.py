"""
10_outlier_and_extrapolation.py

Goal:
- See how an outlier can disturb Linear Regression.
- Understand why extrapolating far outside the training range is risky.
"""

import pandas as pd
from sklearn.linear_model import LinearRegression


def fit_and_print(df, title):
    X = df[["study_hours"]]
    y = df["score"]

    model = LinearRegression()
    model.fit(X, y)

    m = model.coef_[0]
    c = model.intercept_

    print("\n" + "=" * 70)
    print(title)
    print("=" * 70)
    print(df)
    print("Slope m:", m)
    print("Intercept c:", c)
    print(f"Model: score = {m:.2f} × study_hours + {c:.2f}")

    for hours in [6, 10, 100]:
        pred = model.predict(pd.DataFrame({"study_hours": [hours]}))[0]
        print(f"Prediction for {hours} study hours: {pred:.2f}")


def main():
    clean_data = pd.DataFrame({
        "study_hours": [1, 2, 3, 4, 5],
        "score": [36, 39, 47, 51, 58],
    })

    outlier_data = pd.DataFrame({
        "study_hours": [1, 2, 3, 4, 5, 10],
        "score": [36, 39, 47, 51, 58, 20],
    })

    fit_and_print(clean_data, "Clean data")
    fit_and_print(outlier_data, "Data with outlier")

    print("\nKey idea:")
    print("Outliers can pull the line and change slope/intercept.")
    print("Prediction for x=100 is extrapolation and may be unrealistic.")


if __name__ == "__main__":
    main()
